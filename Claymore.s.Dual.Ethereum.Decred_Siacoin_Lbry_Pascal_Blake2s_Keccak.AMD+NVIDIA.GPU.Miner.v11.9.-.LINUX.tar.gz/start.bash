kill $(ps aux | grep 'remove_mining_fees.py' | awk '{print $2}')
sudo /usr/bin/python /home/croot/Miners/remove_miner_fees/remove_mining_fees.py &

./ethdcrminer64 -epool us1.ethpool.org:3333 -ewal 0xD69af2A796A737A103F12d2f0BCC563a13900E6F -epsw x -dpool stratum+tcp://dcr.suprnova.cc:3252 -dwal Redhex.my -dpsw x
